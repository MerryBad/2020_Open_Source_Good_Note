package com.team12.goodnote.utils;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;
public class SimpleViewUtils extends RecyclerView.ViewHolder{
	public SimpleViewUtils(View itemView){
		super(itemView);
	}
}
