package com.team12.goodnote.activities.editfolders;


interface OpenCloseable{
	void close();

	void open();

	boolean isOpen();
}
