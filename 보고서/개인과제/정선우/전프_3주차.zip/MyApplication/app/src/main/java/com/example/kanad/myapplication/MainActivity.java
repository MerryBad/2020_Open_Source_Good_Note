package com.example.kanad.myapplication;
/* **********************************************
 * 프로그램명 : activity-main.xml
 * 작성자 : 2015041074 정선우
 * 작성일 : 2020.04.12
 *프로그램 설명 : 주소를 입력받아 toast 메세지로 출력
 *               입력된 주소로 홈페이지 열기
 *               라디오 버튼을 클릭하면 다른 이미지로 변경
 *               OnCreate 밖에서 findViewId함수를 사용했다가 하루 내내 디버깅했다..
 *********************************************** */

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    Button button1;
    Button button2;
    ImageView image;
    RadioGroup rGroup;
    RadioButton rButton1;
    RadioButton rButton2;
    String myStr;
    Intent mIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText=(EditText)findViewById(R.id.edit_Text);
        button1=(Button)findViewById(R.id.button1);
        button2=(Button)findViewById(R.id.button2);
        image=(ImageView)findViewById(R.id.image1);
        rGroup=(RadioGroup)findViewById(R.id.rGroup);
        rButton1=(RadioButton)findViewById(R.id.radio1);
        rButton2=(RadioButton)findViewById(R.id.radio2);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myStr=editText.getText().toString();
                Toast.makeText(getApplicationContext(), myStr, Toast.LENGTH_SHORT).show();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myStr=editText.getText().toString();
                mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(myStr));
                startActivity(mIntent);
            }
        });

        rGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                rButton1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        image.setImageResource(R.drawable.ya);
                    }
                });
                rButton2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        image.setImageResource(R.drawable.nugul);}
                });
            }
        });
    }
}
